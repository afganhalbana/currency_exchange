
# Shopee Currency Service - Backend Test

## Running
### Without Docker ###
``` go run main.go ```
### With Docker ###
``` docker build -t shopee-service . ```


### Testing References ###
Postman link can be found at https://www.getpostman.com/collections/d5cb7ceace58543e0748

## Versions
1.0-SNAPSHOT: Contains Add and Remove Currencies, Also Add and Get List of Currency Exchange Rate 

## Authors
[afganhalbana](https://github.com/afganhalbana)

License
MIT

