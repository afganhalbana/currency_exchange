package database_test

import (
	"testing"
)

func TestSaveCurrencyExchange(t *testing.T) {

}

func TestFindCurrencyExchangeByID(t *testing.T) {

}

func TestFindCurrencyExchangeFromTo(t *testing.T) {

}

func TestFindAllCurrencyExchange(t *testing.T) {

}
