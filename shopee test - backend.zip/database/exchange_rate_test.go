package database_test

import (
	"testing"
)

func TestSaveExchangeRate(t *testing.T) {

}

func TestFindExchangeRateByID(t *testing.T) {

}

func TestFindRateExchangeRateByID(t *testing.T) {

}

func TestFindRateAverageWeeklyExchangeRateByID(t *testing.T) {

}
